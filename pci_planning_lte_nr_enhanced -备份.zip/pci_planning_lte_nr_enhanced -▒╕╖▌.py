#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
LTE/NR分离式PCI规划工具 - 支持mod30逻辑
主要特性：
1. 从待规划小区文件的LTE和NR工作表分别读取数据
2. NR小区使用mod30逻辑替代mod3逻辑
3. LTE和NR规划结果分别保存到不同文件
4. 优先确保最小PCI复用距离
"""

import pandas as pd
import numpy as np
import math
from typing import Dict, List, Tuple, Set, Optional, Union
from datetime import datetime
import time
import warnings
warnings.filterwarnings('ignore')

class LTENRPCIPlanner:
    def __init__(self, reuse_distance_km: float = 3.0, lte_inherit_mod3: bool = False, 
                 nr_inherit_mod30: bool = False, network_type: str = "LTE"):
        """
        初始化LTE/NR分离式PCI规划工具
        
        Args:
            reuse_distance_km: 最小PCI复用距离（公里）
            lte_inherit_mod3: LTE小区是否继承原PCI的模3值
            nr_inherit_mod30: NR小区是否继承原PCI的模30值  
            network_type: 当前处理的网络类型 ("LTE" 或 "NR")
        """
        self.reuse_distance_km = reuse_distance_km
        self.lte_inherit_mod3 = lte_inherit_mod3
        self.nr_inherit_mod30 = nr_inherit_mod30
        self.network_type = network_type
        
        # PCI范围根据网络类型设定
        if network_type == "LTE":
            self.pci_range = list(range(0, 504))  # LTE PCI范围 0-503
            self.inherit_mod = lte_inherit_mod3
            self.mod_value = 3  # LTE使用mod3
        else:  # NR
            self.pci_range = list(range(0, 1008))  # NR PCI范围 0-1007
            self.inherit_mod = nr_inherit_mod30
            self.mod_value = 30  # NR使用mod30
        
        # 数据存储
        self.cells_to_plan = None
        self.target_cells = None  # 目标网络类型的小区数据
        self.all_cells_combined = None  # 合并的所有小区数据（用于干扰分析）
        
        # 性能优化缓存
        self.distance_cache = {}  # 距离计算结果缓存
        self.pci_validity_cache = {}  # PCI验证结果缓存
        self.same_site_cache = {}  # 同站点信息缓存
        
        # 失败原因统计
        self.failure_reasons = {
            'cell_not_found': [],
            'no_location': [],
            'reuse_distance_violation': [],
            'no_compliant_pci': [],
            'fallback_assignments': [],
            'same_site_mod_conflicts': []  # 同站点模值冲突统计
        }
        
        print(f"初始化{network_type}网络PCI规划工具")
        print(f"同频PCI最小复用距离: {reuse_distance_km}km (优先级最高)")
        print(f"PCI分配策略 (按优先级):")
        print(f"  1. 最小复用距离 (最高优先级) - 确保同频同PCI小区间距离≥{reuse_distance_km}km")
        print(f"  2. 同站点模{self.mod_value}冲突避免 (第二优先级) - 避免同基站小区模值相同")
        print(f"  3. PCI分布均衡性 (第三优先级) - 优选复用距离接近阈值的PCI")
        
        if network_type == "LTE":
            if lte_inherit_mod3:
                print(f"模3继承: 是 - 严格按照原PCI的mod3值分配")
            else:
                print(f"模3继承: 否 - 自由规划，不考虑mod3值")
        else:
            if nr_inherit_mod30:
                print(f"模30继承: 是 - 严格按照原PCI的mod30值分配")
            else:
                print(f"模30继承: 否 - 自由规划，不考虑mod30值")
                
        print(f"PCI范围: 0-{max(self.pci_range)}")
        print(f"核心规则: 只有同频(earfcnDl相同)且PCI相同的小区才需要遵循最小复用距离")
    
    def generate_timestamp_suffix(self) -> str:
        """
        生成时间后缀，格式：YYYYMMDD_HHMMSS
        """
        now = datetime.now()
        return now.strftime("%Y%m%d_%H%M%S")
    
    def convert_to_numeric(self, df: pd.DataFrame, columns: List[str]) -> pd.DataFrame:
        """
        转换指定列为数值格式，处理文本格式数据
        """
        df_copy = df.copy()
        
        for col in columns:
            if col in df_copy.columns:
                # 转换为字符串，处理各种数据类型
                df_copy[col] = df_copy[col].astype(str)
                
                # 移除空格和特殊字符
                df_copy[col] = df_copy[col].str.replace(' ', '').str.replace(',', '')
                
                # 处理 'nan', 'None', 空字符串等
                df_copy[col] = df_copy[col].replace(['nan', 'None', '', 'null'], np.nan)
                
                # 转换为数值
                df_copy[col] = pd.to_numeric(df_copy[col], errors='coerce')
        
        return df_copy
    
    def load_data(self, cells_file: str, params_file: str):
        """
        加载数据文件 - 支持分离式LTE/NR工作表
        """
        print(f"\\n加载数据文件...")
        print(f"规划小区文件: {cells_file}")
        print(f"参数文件: {params_file}")
        
        try:
            # 加载规划小区数据 - 从对应的工作表读取
            worksheet_name = self.network_type  # "LTE" 或 "NR"
            print(f"正在从'{worksheet_name}'工作表加载待规划小区...")
            
            self.cells_to_plan = pd.read_excel(cells_file, sheet_name=worksheet_name)
            print(f"规划小区数据加载成功: {len(self.cells_to_plan)} 行")
            
            # 列名标准化检查
            if self.network_type == "NR" and 'gNodeBID' in self.cells_to_plan.columns:
                # NR网络应使用gNodeBID列，不需要映射
                print("NR网络使用gNodeBID列作为基站标识")
            elif self.network_type == "LTE" and 'eNodeBID' in self.cells_to_plan.columns:
                print("LTE网络使用eNodeBID列作为基站标识")
            
            # 加载参数文件，根据网络类型选择工作表
            if self.network_type == "LTE":
                params_worksheet = "LTE Project Parameters"
            else:
                params_worksheet = "NR Project Parameters"
            
            print(f"正在加载{params_worksheet}工作表...")
            
            # 读取目标网络类型的数据
            target_raw = pd.read_excel(params_file, sheet_name=params_worksheet)
            self.target_cells = self.preprocess_target_cells(target_raw)
            
            # 只使用当前网络类型的数据进行干扰分析（不跨网络类型）
            self.all_cells_combined = self.target_cells.copy()
            print(f"加载{self.network_type}小区数据: {len(self.all_cells_combined)} 个")
                
        except Exception as e:
            print(f"错误: 无法加载{self.network_type}工作表: {e}")
            raise
    
    def preprocess_target_cells(self, raw_df: pd.DataFrame) -> pd.DataFrame:
        """
        预处理目标网络类型的小区数据
        """
        if raw_df.empty:
            return pd.DataFrame()
        
        processed = pd.DataFrame()
        
        if self.network_type == "LTE":
            # LTE列映射
            processed['enodeb_id'] = raw_df['eNodeB标识\neNodeB ID\nlong:[0..1048575]']
            processed['cell_id'] = raw_df['小区标识\ncellLocalId\ninteger:[0~2147483647]']
            processed['cell_name'] = raw_df['小区名称\nuserLabel\nstring[0..128]']
            processed['pci'] = raw_df['物理小区识别码\nPCI\nlong:[0..503]']
            processed['lat'] = raw_df['小区纬度\neNodeB Latitude\ndouble:[-90..90]']
            processed['lon'] = raw_df['小区经度\neNodeB Longitude double:[-180..180]']
            processed['earfcn_dl'] = raw_df['下行链路的中心载频\nearfcnDl\ndouble Step：0.1 \nUnite：MHz']
        else:
            # NR列映射  
            processed['enodeb_id'] = raw_df['gNodeB标识\ngNodeB ID\nLong:[0..1048575]']
            processed['cell_id'] = raw_df['小区标识\ncellLocalId\nInteger:[0~2147483647]']
            processed['cell_name'] = raw_df['小区名称\nCELL NAME\nString[0..128]']
            processed['pci'] = raw_df['物理小区识别码\nPCI\nLong:[0..1007]']
            processed['lat'] = raw_df['小区纬度\nCell  Latitude\nDouble:[-90..90]']
            processed['lon'] = raw_df['小区经度\nCell  Longitude Double:[-180..180]']
            processed['earfcn_dl'] = raw_df['填写SSB频点\nSSB Frequency\nDouble Step：0.01 \nUnite：MHz']
        
        processed['cell_type'] = self.network_type
        
        # 转换所有数值列（cell_name保持字符串格式）
        print(f"转换{self.network_type}小区数值格式...")
        numeric_cols = ['enodeb_id', 'cell_id', 'pci', 'lat', 'lon', 'earfcn_dl']
        processed = self.convert_to_numeric(processed, numeric_cols)
        
        # 过滤掉缺少关键信息的小区
        before_count = len(processed)
        
        # 记录被移除的小区信息
        invalid_cells = processed[processed['enodeb_id'].isna() | processed['cell_id'].isna()]
        
        processed = processed.dropna(subset=['enodeb_id', 'cell_id'])
        after_count = len(processed)
        
        if before_count != after_count:
            print(f"{self.network_type}数据清理: 移除了 {before_count - after_count} 个缺少关键信息的记录")
            if not invalid_cells.empty:
                print("被移除的小区信息:")
                for idx, cell in invalid_cells.iterrows():
                    enodeb_id = cell.get('enodeb_id', '缺失')
                    cell_id = cell.get('cell_id', '缺失')
                    cell_name = cell.get('cell_name', '未知')
                    print(f"  - 基站ID: {enodeb_id}, 小区ID: {cell_id}, 小区名称: {cell_name}")
        
        print(f"{self.network_type}小区预处理完成，有效小区数量: {len(processed)}")
        return processed
    
    
    def calculate_distance_vectorized(self, lat1, lon1, lat2_array, lon2_array):
        """
        向量化距离计算（带缓存优化）
        """
        # 生成缓存键
        cache_key = (round(lat1, 6), round(lon1, 6), 
                    tuple(np.round(lat2_array, 6)), tuple(np.round(lon2_array, 6)))
        
        if cache_key in self.distance_cache:
            return self.distance_cache[cache_key]
        
        # 转换为弧度
        lat1_rad = math.radians(lat1)
        lon1_rad = math.radians(lon1)
        lat2_rad = np.radians(lat2_array)
        lon2_rad = np.radians(lon2_array)
        
        # Haversine公式
        dlat = lat2_rad - lat1_rad
        dlon = lon2_rad - lon1_rad
        a = np.sin(dlat/2)**2 + math.cos(lat1_rad) * np.cos(lat2_rad) * np.sin(dlon/2)**2
        c = 2 * np.arcsin(np.sqrt(a))
        
        result = c * 6371  # 地球半径（公里）
        self.distance_cache[cache_key] = result
        return result
    
    def get_cell_info(self, enodeb_id: int, cell_id: int) -> Tuple[Optional[pd.Series], str]:
        """
        获取小区详细信息
        
        Returns:
            (cell_info, status)
        """
        # 在所有小区中查找（包含完整的位置信息）
        mask = (self.all_cells_combined['enodeb_id'] == enodeb_id) & (self.all_cells_combined['cell_id'] == cell_id)
        matches = self.all_cells_combined[mask]
        
        if matches.empty:
            return None, 'cell_not_found'
        
        cell_info = matches.iloc[0]
        
        # 检查位置信息
        if pd.isna(cell_info['lat']) or pd.isna(cell_info['lon']):
            return cell_info, 'no_location'
        
        return cell_info, 'success'
    
    def validate_pci_reuse_distance(self, candidate_pci: int, target_lat: float, target_lon: float, 
                                   target_earfcn: float, exclude_enodeb: int = None, exclude_cell: int = None) -> Tuple[bool, float]:
        """
        验证候选PCI是否满足最小复用距离要求（带缓存优化）
        """
        if self.all_cells_combined is None or self.all_cells_combined.empty:
            return True, float('inf')
        
        # 生成缓存键
        cache_key = (candidate_pci, round(target_lat, 6), round(target_lon, 6), 
                    round(target_earfcn, 2), exclude_enodeb, exclude_cell)
        
        if cache_key in self.pci_validity_cache:
            return self.pci_validity_cache[cache_key]
        
        # 只查找同频同PCI的小区，并且只考虑同网络类型
        same_freq_same_pci_cells = self.target_cells[
            (self.target_cells['pci'] == candidate_pci) &
            (self.target_cells['pci'].notna()) &
            (self.target_cells['earfcn_dl'] == target_earfcn) &  # 同频条件
            (self.target_cells['earfcn_dl'].notna()) &
            (self.target_cells['cell_type'] == self.network_type)  # 同网络类型
        ].copy()
        
        # 排除当前小区自己
        if exclude_enodeb is not None and exclude_cell is not None:
            same_freq_same_pci_cells = same_freq_same_pci_cells[
                ~((same_freq_same_pci_cells['enodeb_id'] == exclude_enodeb) & 
                  (same_freq_same_pci_cells['cell_id'] == exclude_cell))
            ]
        
        # 过滤有效位置的小区
        same_freq_same_pci_cells = same_freq_same_pci_cells.dropna(subset=['lat', 'lon'])
        
        if same_freq_same_pci_cells.empty:
            result = (True, float('inf'))
            self.pci_validity_cache[cache_key] = result
            return result
        
        # 计算到所有同频同PCI小区的距离
        distances = self.calculate_distance_vectorized(
            target_lat, target_lon,
            same_freq_same_pci_cells['lat'].values,
            same_freq_same_pci_cells['lon'].values
        )
        
        min_distance = np.min(distances)
        is_valid = min_distance >= self.reuse_distance_km
        
        result = (is_valid, min_distance)
        self.pci_validity_cache[cache_key] = result
        return result
    
    def get_same_site_cells(self, target_enodeb_id: int, exclude_cell_id: int = None) -> List[Dict]:
        """
        获取同站点的其他小区信息（带缓存优化）
        """
        # 生成缓存键
        cache_key = (target_enodeb_id, exclude_cell_id)
        
        if cache_key in self.same_site_cache:
            return self.same_site_cache[cache_key]
        
        # 从目标网络类型的小区中查找同站点小区
        same_site_cells = self.target_cells[
            self.target_cells['enodeb_id'] == target_enodeb_id
        ].copy()
        
        # 排除指定的小区ID
        if exclude_cell_id is not None:
            same_site_cells = same_site_cells[
                same_site_cells['cell_id'] != exclude_cell_id
            ]
        
        # 只返回已分配PCI的小区
        same_site_cells = same_site_cells[
            same_site_cells['pci'].notna() & (same_site_cells['pci'] != -1)
        ]
        
        result = same_site_cells.to_dict('records')
        self.same_site_cache[cache_key] = result
        return result
    
    def check_same_site_mod_conflict(self, candidate_pci: int, target_enodeb_id: int, exclude_cell_id: int = None) -> bool:
        """
        检查候选PCI是否与同站点其他小区的模值冲突
        
        Args:
            candidate_pci: 候选PCI值
            target_enodeb_id: 目标基站ID
            exclude_cell_id: 要排除的小区ID
            
        Returns:
            True表示无冲突，False表示有冲突
        """
        candidate_mod = candidate_pci % self.mod_value
        same_site_cells = self.get_same_site_cells(target_enodeb_id, exclude_cell_id)
        
        # 检查是否与同站点其他小区的模值冲突
        for cell in same_site_cells:
            existing_pci = cell['pci']
            if pd.notna(existing_pci) and existing_pci != -1:
                existing_mod = int(existing_pci) % self.mod_value
                if existing_mod == candidate_mod:
                    return False  # 发现冲突
        
        return True  # 无冲突

    def get_reuse_compliant_pcis(self, target_lat: float, target_lon: float, target_earfcn: float,
                                exclude_enodeb: int = None, exclude_cell: int = None,
                                target_mod: Optional[int] = None) -> List[Tuple[int, float, int, bool]]:
        """
        获取满足复用距离要求的PCI列表，按照多重优先级排序
        
        Returns:
            List of (pci, min_distance_to_same_pci, mod_conflict_penalty, is_balanced) tuples, sorted by preference
        """
        compliant_pcis = []
        
        # 如果需要继承mod值，严格按照mod值筛选PCI范围
        if self.inherit_mod and target_mod is not None:
            # 严格继承模式：只考虑匹配mod值的PCI
            candidate_pcis = [pci for pci in self.pci_range if pci % self.mod_value == target_mod]
            print(f"    严格mod{self.mod_value}继承模式: 只检查mod{self.mod_value}={target_mod}的PCI，候选PCI数量: {len(candidate_pcis)}")
        else:
            # 自由规划模式：考虑所有PCI，不考虑mod值
            candidate_pcis = self.pci_range
            print(f"    自由规划模式: 检查所有PCI，不考虑mod{self.mod_value}值，候选PCI数量: {len(candidate_pcis)}")
        
        # 检查候选PCI
        for pci in candidate_pcis:
            # 1. 首先检查复用距离（最高优先级）
            is_valid, min_distance = self.validate_pci_reuse_distance(
                pci, target_lat, target_lon, target_earfcn, exclude_enodeb, exclude_cell
            )
            
            if not is_valid:
                continue  # 不满足复用距离要求的PCI直接跳过
            
            # 2. 检查同站点模值冲突（第二优先级）
            no_same_site_mod_conflict = True
            if exclude_enodeb is not None:
                no_same_site_mod_conflict = self.check_same_site_mod_conflict(
                    pci, exclude_enodeb, exclude_cell
                )
            
            # 3. 计算PCI分布均衡性指标（第三优先级）
            # 距离越接近阈值越均衡
            if min_distance == float('inf'):
                balance_score = 0  # 无复用PCI，最均衡
            else:
                # 距离接近阈值的得分更高（分数越小越好）
                balance_score = abs(min_distance - self.reuse_distance_km)
            
            compliant_pcis.append((pci, min_distance, no_same_site_mod_conflict, balance_score))
        
        if not compliant_pcis:
            return []
        
        # 多重优先级排序策略
        def sort_key(pci_info):
            pci, distance, no_mod_conflict, balance_score = pci_info
            
            # 优先级1：复用距离（已在筛选阶段保证，这里用于进一步排序）
            # 距离越大越安全，但不要过度追求（用负值因为sort是升序）
            if distance == float('inf'):
                distance_priority = -999999  # 无复用PCI最优
            else:
                distance_priority = -distance  # 距离大的优先，但会被后续优先级调节
            
            # 优先级2：同站点模值冲突避免（第二重要）
            mod_conflict_penalty = 0 if no_mod_conflict else 1000000  # 有冲突的大幅降低优先级
            
            # 优先级3：PCI分布均衡性（第三重要）
            balance_priority = balance_score  # 越接近阈值越好
            
            # 优先级4：PCI值（确定性，小的优先）
            pci_priority = pci
            
            return (mod_conflict_penalty, balance_priority, distance_priority, pci_priority)
        
        compliant_pcis.sort(key=sort_key)
        
        # 转换回原格式以保持兼容性
        return [(pci, distance) for pci, distance, _, _ in compliant_pcis]
    
    def assign_pci_with_reuse_priority(self, enodeb_id: int, cell_id: int) -> Tuple[int, str, float, float]:
        """
        优先确保复用距离的PCI分配方法
        
        Returns:
            (assigned_pci, reason, earfcn_dl, actual_min_reuse_distance)
        """
        # 获取小区信息
        cell_info, status = self.get_cell_info(enodeb_id, cell_id)
        
        if status != 'success':
            # 对于找不到的小区或缺少位置信息的小区，使用保底分配
            if status == 'cell_not_found':
                fallback_pci = (enodeb_id + cell_id) % len(self.pci_range)
                return fallback_pci, 'cell_not_found_fallback', 0.0, 0.0
            elif status == 'no_location':
                fallback_pci = (enodeb_id + cell_id + 100) % len(self.pci_range)
                earfcn_dl = cell_info['earfcn_dl'] if cell_info is not None else 0.0
                return fallback_pci, 'no_location_fallback', earfcn_dl, 0.0
        
        target_lat = cell_info['lat']
        target_lon = cell_info['lon']
        earfcn_dl = cell_info['earfcn_dl']
        
        # 确定目标mod值（如果需要继承）
        target_mod = None
        if self.inherit_mod and not pd.isna(cell_info['pci']):
            target_mod = int(cell_info['pci']) % self.mod_value
        
        # 获取满足复用距离的PCI列表（同频检查）
        compliant_pcis = self.get_reuse_compliant_pcis(
            target_lat, target_lon, earfcn_dl, enodeb_id, cell_id, target_mod
        )
        
        if not compliant_pcis:
            # 没有满足复用距离的PCI，记录违规并使用保底方案
            self.failure_reasons['no_compliant_pci'].append(f"{enodeb_id}-{cell_id}")
            fallback_pci = enodeb_id % len(self.pci_range)
            return fallback_pci, 'no_compliant_pci_fallback', earfcn_dl, 0.0
        
        # 选择最优的PCI（经过多重优先级排序后的第一个）
        best_pci, min_distance = compliant_pcis[0]
        
        # 检查选择的PCI的特性
        best_pci_mod = best_pci % self.mod_value
        same_site_mod_ok = self.check_same_site_mod_conflict(best_pci, enodeb_id, cell_id)
        
        # 显示PCI选择的详细信息
        print(f"    小区{enodeb_id}-{cell_id}: 候选PCI数量={len(compliant_pcis)}")
        if len(compliant_pcis) > 1:
            top_candidates = compliant_pcis[:min(3, len(compliant_pcis))]
            print(f"    前{len(top_candidates)}个候选PCI: {[(pci, f'{dist:.2f}km') for pci, dist in top_candidates]}")
        
        print(f"    选择PCI={best_pci} (mod{self.mod_value}={best_pci_mod})")
        print(f"      复用距离: {min_distance:.2f}km")
        print(f"      同站点模{self.mod_value}冲突: {'无' if same_site_mod_ok else '有'}")
        
        if min_distance != float('inf'):
            if abs(min_distance - self.reuse_distance_km) <= 2:
                print(f"      均衡性: 优秀 (接近{self.reuse_distance_km}km阈值)")
            elif min_distance <= self.reuse_distance_km + 5:
                print(f"      均衡性: 良好 (适中距离)")
            else:
                print(f"      均衡性: 一般 (距离较远)")
        
        # 确定分配原因
        if self.inherit_mod and target_mod is not None:
            # 继承模式：由于严格筛选，分配的PCI必然匹配mod值
            if self.network_type == "LTE":
                reason = 'strict_mod3_inheritance'
            else:
                reason = 'strict_mod30_inheritance'
        else:
            # 自由规划模式：仅考虑复用距离
            reason = 'free_planning_reuse_compliant'
        
        return best_pci, reason, earfcn_dl, min_distance
    
    def calculate_pci_mod(self, pci_value) -> Optional[int]:
        """
        计算PCI的模值（LTE为mod3，NR为mod30）
        """
        if pci_value is None or pci_value == -1 or pd.isna(pci_value):
            return None
        try:
            return int(pci_value) % self.mod_value
        except (ValueError, TypeError):
            return None
    
    def update_cell_pci(self, enodeb_id: int, cell_id: int, assigned_pci: int):
        """
        更新小区的PCI值
        """
        mask = (self.target_cells['enodeb_id'] == enodeb_id) & (self.target_cells['cell_id'] == cell_id)
        self.target_cells.loc[mask, 'pci'] = assigned_pci
        
        # 同时更新合并数据
        if self.all_cells_combined is not None:
            combined_mask = ((self.all_cells_combined['enodeb_id'] == enodeb_id) & 
                           (self.all_cells_combined['cell_id'] == cell_id) & 
                           (self.all_cells_combined['cell_type'] == self.network_type))
            self.all_cells_combined.loc[combined_mask, 'pci'] = assigned_pci
    
    def calculate_final_min_reuse_distance(self, result_df: pd.DataFrame) -> List[str]:
        """
        计算每个小区的最终最小PCI复用距离（验证分配结果）
        返回字符串格式，将inf标记为"无复用PCI"
        """
        print("\\n正在验证最终复用距离...")
        min_reuse_distances = []
        
        for idx, cell in result_df.iterrows():
            # 根据网络类型获取正确的列名
            if self.network_type == "NR":
                enodeb_id = cell.get('gNodeBID')
            else:
                enodeb_id = cell.get('eNodeBID')
            cell_id = cell.get('CellID')
            assigned_pci = cell.get('分配的PCI')
            
            if assigned_pci == -1:
                min_reuse_distances.append("分配失败")
                continue
            
            # 获取当前小区信息
            cell_info, status = self.get_cell_info(enodeb_id, cell_id)
            
            if status != 'success' or pd.isna(cell_info['lat']) or pd.isna(cell_info['lon']):
                min_reuse_distances.append("位置信息缺失")
                continue
            
            # 验证实际复用距离（同频检查）
            _, actual_min_distance = self.validate_pci_reuse_distance(
                assigned_pci, cell_info['lat'], cell_info['lon'], cell_info['earfcn_dl'], enodeb_id, cell_id
            )
            
            # 格式化输出
            if actual_min_distance == float('inf'):
                min_reuse_distances.append("无复用PCI")
            else:
                min_reuse_distances.append(f"{actual_min_distance:.2f}")
            
            if (idx + 1) % 100 == 0 or (idx + 1) == len(result_df):
                print(f"已验证 {idx+1}/{len(result_df)} 个小区的复用距离")
        
        return min_reuse_distances
    
    def plan_pci_with_reuse_priority(self) -> pd.DataFrame:
        """
        执行优先确保复用距离的PCI规划
        """
        if self.cells_to_plan is None:
            raise ValueError("请先加载数据")
        
        start_time = time.time()
        
        print(f"\\n开始{self.network_type}网络PCI规划（优先确保同频PCI复用距离）")
        print(f"同频PCI最小复用距离: {self.reuse_distance_km}km (优先级最高)")
        print(f"PCI范围: 0-{max(self.pci_range)}")
        
        if self.network_type == "LTE":
            if self.lte_inherit_mod3:
                print(f"规划模式: 严格mod3继承 - 只分配匹配原PCI mod3值的PCI")
            else:
                print(f"规划模式: 自由规划 - 不考虑mod3值，优先复用距离")
        else:
            if self.nr_inherit_mod30:
                print(f"规划模式: 严格mod30继承 - 只分配匹配原PCI mod30值的PCI")
            else:
                print(f"规划模式: 自由规划 - 不考虑mod30值，优先复用距离")
                
        print(f"核心规则: 只有同频同PCI的小区才需要遵循最小复用距离")
        
        # 重置统计
        self.failure_reasons = {
            'cell_not_found': [],
            'no_location': [],
            'reuse_distance_violation': [],
            'no_compliant_pci': [],
            'fallback_assignments': []
        }
        
        # 复制规划小区数据
        result_df = self.cells_to_plan.copy()
        
        # 初始化新列
        cell_names = []
        assigned_pcis = []
        original_pcis = []
        original_mods = []
        assigned_mods = []
        mod_same_flags = []
        earfcn_dls = []
        assignment_reasons = []
        predicted_min_distances = []
        
        total_cells = len(result_df)
        
        for idx, cell in result_df.iterrows():
            # 根据网络类型选择正确的基站ID列
            if self.network_type == "NR":
                enodeb_id = cell.get('gNodeBID')
            else:
                enodeb_id = cell.get('eNodeBID')
            cell_id = cell.get('CellID')
            
            # 显示进度
            if (idx + 1) % 50 == 0 or (idx + 1) == total_cells:
                print(f"正在规划小区 {idx+1}/{total_cells}")
            
            # 获取原PCI信息和小区名称
            cell_info, _ = self.get_cell_info(enodeb_id, cell_id)
            original_pci = cell_info['pci'] if cell_info is not None else None
            # 获取小区名称并清理
            if cell_info is not None and 'cell_name' in cell_info and not pd.isna(cell_info['cell_name']):
                cell_name = str(cell_info['cell_name']).strip()
                # 过滤掉模板行的标识
                if cell_name in ['非必填', 'UserLabel', '必填']:
                    cell_name = f"小区_{enodeb_id}_{cell_id}"
            else:
                cell_name = f"小区_{enodeb_id}_{cell_id}"
            
            original_pcis.append(original_pci)
            cell_names.append(cell_name)
            
            # 计算原PCI的模值
            original_mod = self.calculate_pci_mod(original_pci)
            original_mods.append(original_mod)
            
            # 分配PCI（优先确保复用距离）
            assigned_pci, reason, earfcn_dl, predicted_distance = self.assign_pci_with_reuse_priority(enodeb_id, cell_id)
            assigned_pcis.append(assigned_pci)
            earfcn_dls.append(earfcn_dl)
            assignment_reasons.append(reason)
            predicted_min_distances.append(predicted_distance)
            
            # 记录特殊情况
            if 'not_found' in reason:
                self.failure_reasons['cell_not_found'].append(f"{enodeb_id}-{cell_id}")
            elif 'no_location' in reason:
                self.failure_reasons['no_location'].append(f"{enodeb_id}-{cell_id}")
            elif 'no_compliant' in reason:
                self.failure_reasons['no_compliant_pci'].append(f"{enodeb_id}-{cell_id}")
            elif 'fallback' in reason:
                self.failure_reasons['fallback_assignments'].append(f"{enodeb_id}-{cell_id}")
            
            # 计算分配PCI的模值
            assigned_mod = self.calculate_pci_mod(assigned_pci)
            assigned_mods.append(assigned_mod)
            
            # 比较模值
            if original_mod is not None and assigned_mod is not None:
                mod_same = '是' if original_mod == assigned_mod else '否'
            else:
                mod_same = '无法比较'
            mod_same_flags.append(mod_same)
            
            # 更新小区PCI（用于后续小区的规划）
            self.update_cell_pci(enodeb_id, cell_id, assigned_pci)
        
        # 添加所有新列，根据网络类型调整列结构
        # 先保存原有的列
        original_columns = list(result_df.columns)
        
        # 根据网络类型决定是否包含eNodeBID列
        if self.network_type == "NR":
            # NR网络：删除eNodeBID列，只保留CellID和小区名称
            print("    NR网络：删除冗余的eNodeBID列")
            filtered_columns = [col for col in original_columns if col != 'eNodeBID']
            # 在CellID后插入小区名称
            if 'CellID' in filtered_columns:
                cellid_index = filtered_columns.index('CellID')
                new_columns = filtered_columns[:cellid_index+1] + ['小区名称'] + filtered_columns[cellid_index+1:]
            else:
                new_columns = ['小区名称'] + filtered_columns
        else:
            # LTE网络：保持原有结构，在第3列插入小区名称
            new_columns = original_columns[:2] + ['小区名称'] + original_columns[2:]
        
        # 重新组织DataFrame
        result_df_new = pd.DataFrame()
        for i, col in enumerate(new_columns):
            if col == '小区名称':
                result_df_new[col] = cell_names
            elif col in original_columns:
                # 只添加存在的原始列
                result_df_new[col] = result_df[col].values
        
        # 添加其他新列
        result_df_new['网络类型'] = self.network_type
        result_df_new['原PCI'] = original_pcis
        result_df_new['分配的PCI'] = assigned_pcis
        
        # 根据网络类型设置模值列名
        if self.network_type == "LTE":
            result_df_new['原PCI模3'] = original_mods
            result_df_new['新PCI模3'] = assigned_mods
            result_df_new['模3是否相同'] = mod_same_flags
        else:
            result_df_new['原PCI模30'] = original_mods
            result_df_new['新PCI模30'] = assigned_mods
            result_df_new['模30是否相同'] = mod_same_flags
        
        result_df_new['earfcnDl'] = earfcn_dls
        result_df_new['分配原因'] = assignment_reasons
        
        # 更新result_df
        result_df = result_df_new
        
        # 计算最终验证的最小复用距离
        final_min_distances = self.calculate_final_min_reuse_distance(result_df)
        result_df['最小复用距离(km)'] = final_min_distances
        
        # 计算执行时间
        end_time = time.time()
        execution_time = end_time - start_time
        
        # 统计结果
        self.print_reuse_focused_statistics(result_df, execution_time)
        
        return result_df
    
    def print_reuse_focused_statistics(self, result_df: pd.DataFrame, execution_time: float):
        """
        打印复用距离优先的统计信息
        """
        print(f"\\n=== {self.network_type}网络PCI规划完成（同频PCI复用距离优先） ===")
        print(f"执行时间: {execution_time:.2f} 秒")
        print(f"平均每个小区处理时间: {execution_time/len(result_df):.4f} 秒")
        
        total_cells = len(result_df)
        success_count = len(result_df[result_df['分配的PCI'] != -1])
        
        print(f"规划统计:")
        print(f"  总小区数: {total_cells}")
        print(f"  成功分配: {success_count} ({success_count/total_cells*100:.1f}%)")
        
        # 同频PCI复用距离合规性统计
        distance_col = result_df['最小复用距离(km)']
        
        # 分类统计
        no_reuse_cells = result_df[distance_col == "无复用PCI"]
        failed_cells = result_df[distance_col == "分配失败"]
        location_missing_cells = result_df[distance_col == "位置信息缺失"]
        
        # 数值距离的小区
        numeric_distances = []
        numeric_indices = []
        for idx, dist in distance_col.items():
            if isinstance(dist, str) and dist not in ["无复用PCI", "分配失败", "位置信息缺失"]:
                try:
                    numeric_distances.append(float(dist))
                    numeric_indices.append(idx)
                except ValueError:
                    pass
        
        numeric_df = result_df.loc[numeric_indices] if numeric_indices else pd.DataFrame()
        
        if len(numeric_distances) > 0:
            compliant_numeric = [d for d in numeric_distances if d >= self.reuse_distance_km]
            violation_numeric = [d for d in numeric_distances if d < self.reuse_distance_km]
        else:
            compliant_numeric = []
            violation_numeric = []
        
        print(f"\\n同频PCI复用距离详细统计:")
        print(f"  最小复用距离要求: {self.reuse_distance_km}km (仅适用于同频同PCI小区)")
        print(f"  无复用PCI小区: {len(no_reuse_cells)} ({len(no_reuse_cells)/total_cells*100:.1f}%)")
        print(f"  有复用且合规小区: {len(compliant_numeric)} ({len(compliant_numeric)/total_cells*100:.1f}%)")
        print(f"  有复用但违规小区: {len(violation_numeric)} ({len(violation_numeric)/total_cells*100:.1f}%)")
        
        # 复用距离分布统计（仅针对数值距离）
        if numeric_distances:
            print(f"\\n复用距离分布统计 (有复用PCI的小区):")
            print(f"  平均复用距离: {np.mean(numeric_distances):.2f}km")
            print(f"  最小复用距离: {np.min(numeric_distances):.2f}km")
            print(f"  最大复用距离: {np.max(numeric_distances):.2f}km")
            print(f"  中位数复用距离: {np.median(numeric_distances):.2f}km")
            
            # 距离区间分布
            distance_ranges = [
                (0, self.reuse_distance_km, f"< {self.reuse_distance_km}km (违规)"),
                (self.reuse_distance_km, self.reuse_distance_km + 2, f"{self.reuse_distance_km}-{self.reuse_distance_km + 2}km (接近阈值)"),
                (self.reuse_distance_km + 2, self.reuse_distance_km + 5, f"{self.reuse_distance_km + 2}-{self.reuse_distance_km + 5}km (适中)"),
                (self.reuse_distance_km + 5, float('inf'), f"> {self.reuse_distance_km + 5}km (较远)")
            ]
            
            print(f"  距离区间分布:")
            for min_dist, max_dist, desc in distance_ranges:
                count = sum(1 for d in numeric_distances if min_dist <= d < max_dist)
                if count > 0:
                    print(f"    {desc}: {count} ({count/len(numeric_distances)*100:.1f}%)")
        
        if len(failed_cells) > 0:
            print(f"  分配失败小区: {len(failed_cells)} ({len(failed_cells)/total_cells*100:.1f}%)")
        if len(location_missing_cells) > 0:
            print(f"  位置信息缺失: {len(location_missing_cells)} ({len(location_missing_cells)/total_cells*100:.1f}%)")
        
        # 违规小区详情
        if len(violation_numeric) > 0:
            print(f"\\n  违规小区详情 (前10个):")
            violation_indices = [numeric_indices[i] for i, d in enumerate(numeric_distances) if d < self.reuse_distance_km][:10]
            for idx in violation_indices:
                cell = result_df.loc[idx]
                print(f"    {cell['eNodeBID']}-{cell['CellID']}: 实际距离 {cell['最小复用距离(km)']}km")
        
        # 模值继承统计
        if self.inherit_mod:
            if self.network_type == "LTE":
                mod_col = '模3是否相同'
                mod_name = "模3"
            else:
                mod_col = '模30是否相同'
                mod_name = "模30"
                
            mod_inherited = result_df[result_df[mod_col] == '是']
            mod_rate = len(mod_inherited) / total_cells * 100
            print(f"\\n{mod_name}继承统计:")
            print(f"  {mod_name}继承成功: {len(mod_inherited)} ({mod_rate:.1f}%)")
        
        # 同站点模值冲突分析
        self.analyze_same_site_mod_conflicts(result_df)
        
        # 分配原因统计
        print(f"\\n分配原因统计:")
        reason_counts = result_df['分配原因'].value_counts()
        for reason, count in reason_counts.items():
            print(f"  {reason}: {count} ({count/total_cells*100:.1f}%)")
        
        # 特殊情况统计
        special_cases = 0
        for reason, cells in self.failure_reasons.items():
            if cells:
                special_cases += len(cells)
                print(f"  {reason}: {len(cells)} 个小区")
        
        if special_cases == 0:
            print("\\n[成功] 所有小区均正常分配PCI")
        
        print(f"\\n距离状态说明:")
        print(f"  '无复用PCI': 该小区PCI在同频点内无其他小区使用，满足复用距离要求")
        print(f"  数值(如3.45): 同频同PCI小区间的最小距离(km)")
        print(f"  '分配失败': PCI分配过程失败")
        print(f"  '位置信息缺失': 小区缺少经纬度信息，无法计算距离")
        
        print(f"\\n规划完成！")
    
    def analyze_same_site_mod_conflicts(self, result_df: pd.DataFrame):
        """
        分析同站点模值冲突情况
        """
        print(f"\\n同站点模{self.mod_value}冲突分析:")
        
        # 按基站ID分组统计
        if self.network_type == "LTE":
            enodeb_col = 'eNodeBID'
        else:
            enodeb_col = 'gNodeBID'
        
        conflicts = []
        total_sites = 0
        conflict_sites = 0
        
        # 按基站分组
        for enodeb_id, group in result_df.groupby(enodeb_col):
            total_sites += 1
            
            # 获取该基站下所有小区的PCI和模值
            site_cells = []
            for _, cell in group.iterrows():
                pci = cell['分配的PCI']
                if pd.notna(pci) and pci != -1:
                    mod_value = int(pci) % self.mod_value
                    site_cells.append({
                        'cell_id': cell['CellID'],
                        'pci': int(pci),
                        'mod': mod_value
                    })
            
            if len(site_cells) <= 1:
                continue  # 单小区基站无冲突可能
            
            # 检查模值冲突
            mod_values = [cell['mod'] for cell in site_cells]
            unique_mods = set(mod_values)
            
            if len(unique_mods) < len(mod_values):
                # 发现冲突
                conflict_sites += 1
                
                # 找出冲突的模值
                conflict_mods = []
                for mod in unique_mods:
                    mod_count = mod_values.count(mod)
                    if mod_count > 1:
                        conflict_cells = [cell for cell in site_cells if cell['mod'] == mod]
                        conflict_mods.append((mod, conflict_cells))
                
                conflicts.append({
                    'enodeb_id': enodeb_id,
                    'total_cells': len(site_cells),
                    'conflicts': conflict_mods
                })
        
        # 输出统计结果
        print(f"  总基站数: {total_sites}")
        print(f"  有模{self.mod_value}冲突的基站: {conflict_sites} ({conflict_sites/total_sites*100:.1f}%)")
        print(f"  无模{self.mod_value}冲突的基站: {total_sites - conflict_sites} ({(total_sites - conflict_sites)/total_sites*100:.1f}%)")
        
        if conflicts:
            print(f"\\n  冲突详情 (前5个基站):")
            for i, conflict in enumerate(conflicts[:5]):
                enodeb_id = conflict['enodeb_id']
                print(f"    基站{enodeb_id}: {conflict['total_cells']}个小区")
                for mod, cells in conflict['conflicts']:
                    cell_info = ', '.join([f"小区{cell['cell_id']}(PCI{cell['pci']})" for cell in cells])
                    print(f"      模{self.mod_value}={mod}冲突: {cell_info}")
        
        if conflict_sites == 0:
            print(f"  ✅ 优秀！所有基站都避免了同站点模{self.mod_value}冲突")
        elif conflict_sites / total_sites <= 0.1:
            print(f"  ✅ 良好！大部分基站避免了同站点模{self.mod_value}冲突")
        else:
            print(f"  ⚠️  需要关注：较多基站存在同站点模{self.mod_value}冲突")


def main():
    """
    主函数 - LTE/NR分离式PCI规划工具
    """
    print("=== LTE/NR分离式PCI规划工具 - 支持mod30逻辑 ===\\n")
    
    # 文件路径
    cells_file = "待规划小区/cell-tree-export-20250915204721.xlsx"
    params_file = "全量工参/ProjectParameter_mongoose20250915河源电联.xlsx"
    
    # 检查两种网络类型的待规划小区
    try:
        xl_file = pd.ExcelFile(cells_file)
        available_worksheets = xl_file.sheet_names
        print(f"可用的待规划小区工作表: {available_worksheets}")
        
        lte_cells_count = 0
        nr_cells_count = 0
        
        if "LTE" in available_worksheets:
            lte_df = pd.read_excel(cells_file, sheet_name="LTE")
            lte_cells_count = len(lte_df)
            print(f"LTE待规划小区数量: {lte_cells_count}")
        
        if "NR" in available_worksheets:
            nr_df = pd.read_excel(cells_file, sheet_name="NR") 
            nr_cells_count = len(nr_df)
            print(f"NR待规划小区数量: {nr_cells_count}")
        
        # 用户选择要规划的网络类型
        print(f"\\n请选择要规划的网络类型:")
        if lte_cells_count > 0:
            print(f"1. LTE ({lte_cells_count} 个小区)")
        if nr_cells_count > 0:
            print(f"2. NR ({nr_cells_count} 个小区)")
        print(f"3. 两种类型都规划")
        
        choice = input("请输入选择 (1/2/3): ").strip()
        
        # 用户输入最小复用距离
        while True:
            try:
                reuse_distance = float(input(f"请输入最小PCI复用距离 (km，默认3.0): ").strip() or "3.0")
                if reuse_distance > 0:
                    break
                else:
                    print("复用距离必须大于0，请重新输入")
            except ValueError:
                print("请输入有效的数字")
        
        # 根据选择执行规划
        networks_to_plan = []
        
        if choice == "1" and lte_cells_count > 0:
            networks_to_plan = ["LTE"]
        elif choice == "2" and nr_cells_count > 0:
            networks_to_plan = ["NR"]
        elif choice == "3":
            if lte_cells_count > 0:
                networks_to_plan.append("LTE")
            if nr_cells_count > 0:
                networks_to_plan.append("NR")
        else:
            print("无效选择或没有对应的待规划小区")
            return
        
        # 为每种网络类型执行规划
        for network_type in networks_to_plan:
            print(f"\\n{'='*50}")
            print(f"开始规划 {network_type} 网络")
            print(f"{'='*50}")
            
            # 根据网络类型询问继承选项
            if network_type == "LTE":
                inherit_choice = input("LTE小区是否继承原PCI的模3值？(y/n，默认n): ").strip().lower()
                lte_inherit_mod3 = inherit_choice in ['y', 'yes', '是']
                nr_inherit_mod30 = False
            else:
                inherit_choice = input("NR小区是否继承原PCI的模30值？(y/n，默认n): ").strip().lower()
                nr_inherit_mod30 = inherit_choice in ['y', 'yes', '是']
                lte_inherit_mod3 = False
            
            try:
                # 创建规划器
                planner = LTENRPCIPlanner(
                    reuse_distance_km=reuse_distance,
                    lte_inherit_mod3=lte_inherit_mod3,
                    nr_inherit_mod30=nr_inherit_mod30,
                    network_type=network_type
                )
                
                # 加载数据
                planner.load_data(cells_file, params_file)
                
                # 执行规划
                result_df = planner.plan_pci_with_reuse_priority()
                
                # 生成带时间后缀的文件名
                timestamp = planner.generate_timestamp_suffix()
                if network_type == "LTE":
                    mod_suffix = "mod3" if lte_inherit_mod3 else "nomod3"
                else:
                    mod_suffix = "mod30" if nr_inherit_mod30 else "nomod30"
                    
                output_file = f"pci_planning_{network_type.lower()}_{reuse_distance}km_{mod_suffix}_{timestamp}.xlsx"
                
                result_df.to_excel(output_file, index=False)
                print(f"\\n[成功] {network_type}规划结果已保存到: {output_file}")
                
                # 显示前几行结果
                print(f"\\n{network_type}规划前5行结果预览:")
                display_columns = ['eNodeBID', 'CellID', '小区名称', '原PCI', '分配的PCI', '最小复用距离(km)', '分配原因']
                available_columns = [col for col in display_columns if col in result_df.columns]
                print(result_df[available_columns].head())
                
            except Exception as e:
                print(f"[错误] {network_type}网络规划失败: {e}")
                import traceback
                traceback.print_exc()
        
        print(f"\\n[完成] 所有选定的网络类型规划完成！")
        
    except Exception as e:
        print(f"错误: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()